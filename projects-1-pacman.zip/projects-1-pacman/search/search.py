# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    "*** YOUR CODE HERE ***"
    # ====================================================================== #
    #                  Author: Sijin Chen,   17307130004                     #
    # ====================================================================== #
    # Initialization of the Fringe
    from util import Stack
    from copy import deepcopy
    # Initialization of the Fringe
    visited = set(); stack = Stack()
    stack.push((problem.getStartState(), []))
    # Running DFS Algorithm
    while not stack.isEmpty():
        cur, path = stack.pop()
        # skip the nodes which have been visited
        if cur in visited: continue
        visited.add(cur)
        # If the current state is the goal state, quit searching
        if problem.isGoalState(cur): actions = path; break
        # Expand the Fringe
        for state, move, cost in problem.getSuccessors(cur):
            newAction = deepcopy(path)
            newAction.append(move)
            stack.push((state, newAction))
    return actions
    # ====================================================================== #

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    "*** YOUR CODE HERE ***"
    # ====================================================================== #
    #                  Author: Sijin Chen,   17307130004                     #
    # ====================================================================== #
    from util import Queue
    # Initialization of the Fringe
    queue = Queue()
    queue.push(problem.getStartState())
    # The Structure to store the searching path
    ancestor = {problem.getStartState(): None}
    # BFS search algorithm
    while not queue.isEmpty():
        cur = queue.pop()
        # Update the Fringe and search path
        flag = False
        for state, move, cost in problem.getSuccessors(cur):
            if state not in ancestor:
                queue.push(state)
                ancestor[state] = (cur, move)
            # If the next state is the goal state, quit searching
            if problem.isGoalState(state): 
                cur = state; flag = True; break
        if flag: break
    # Backtracking to construct a searching path
    from collections import deque
    path = deque([])
    while cur != problem.getStartState():
        cur, move = ancestor[cur]
        if move: path.appendleft(move)
    return list(path)
    # ====================================================================== #

def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"
    # ====================================================================== #
    #                  Author: Sijin Chen,   17307130004                     #
    # ====================================================================== #
    from util import PriorityQueue
    # Initialization of the Fringe
    heap = PriorityQueue()
    heap.push(problem.getStartState(), 0)
    # The Structure to store the searching path
    ancestor = {problem.getStartState(): None}
    costs = {problem.getStartState(): 0}; visited = set()
    # The Structure to store the searching path
    while not heap.isEmpty():
        # The information of the current state
        cur = heap.pop(); cur_cost = costs[cur]
        visited.add(cur)
        # If the current state is the goal state, quit searching
        if problem.isGoalState(cur): break
        # Update the Fringe and search path
        for state, move, cost in problem.getSuccessors(cur):
            # The visited nodes are already optimal
            if state in visited: continue
            # Update step can update those already exists, as well as new ones
            heap.update(state, cost + cur_cost)
            # Update the reconstruction steps (use a dictionary to store the path)
            if state not in costs or costs[state] > cost + cur_cost:
                costs[state] = cost + cur_cost
                ancestor[state] = (cur, move)
    # Backtracking to construct a searching path, the same as bfs
    from collections import deque
    path = deque([])
    while cur != problem.getStartState():
        cur, move = ancestor[cur]
        if move: path.appendleft(move)
    return list(path)
    # ====================================================================== #

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
    # ====================================================================== #
    #                  Author: Sijin Chen,   17307130004                     #
    # ====================================================================== #
    from util import PriorityQueue
    # Initialization of the Fringe
    heap = PriorityQueue()
    start = problem.getStartState()
    heap.push(start, 0)
    # The Structure to store the searching path, A_star strategy: f = g + h
    ancestor = {problem.getStartState(): None} 
    costs = {start: 0}; visited = set()
    cost_n_heur = {start: heuristic(start, problem)}
    # The Structure to store the searching path
    while not heap.isEmpty():
        # The information of the current state
        cur = heap.pop(); cur_cost = costs[cur]
        visited.add(cur)
        # If the current state is the goal state, quit searching
        if problem.isGoalState(cur): break
        # Update the Fringe and search path
        for state, move, cost in problem.getSuccessors(cur):
            # The visited nodes are already optimal
            if state in visited: continue
            # Update step can update those already exists, as well as new ones
            heap.update(state, cost + cur_cost + heuristic(state, problem))
            # Update the reconstruction steps (use a dictionary to store the path)
            pos_cost = cost + cur_cost
            pos_heur = heuristic(state, problem)
            # Update the path based on f = g + h
            if state not in cost_n_heur or cost_n_heur[state] > pos_heur + pos_cost:
                costs[state] = pos_cost
                cost_n_heur[state] = pos_cost + pos_heur
                ancestor[state] = (cur, move)
    # Backtracking to construct a searching path, the same as bfs
    from collections import deque
    path = deque([])
    while cur != problem.getStartState():
        cur, move = ancestor[cur]
        if move: path.appendleft(move)
    return list(path)
    # ====================================================================== #


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
