from copy import deepcopy

State = [-2, -1, 0, 1, 2]
Utility = {s: 0 for s in State}
# Reward = dict(zip(State, [20, -5, -5, -5, 100]))
Reward = dict(zip(State, [20, -5, -5, -5, 100]))
Action = dict(zip(State, [{}, {-1, 1}, {-1, 1}, {-1, 1}, {}]))
discount = 1

# %% Begin Value-Iteration
Policy = dict(zip(State, [None for _ in State]))
print('State:\t', '\t'.join(map( str, State )))
string = '\t'.join(['{:.2f}'] * len(State))

while True:
    # Current Utility Result
    print('-' * 50)
    print('U:\t', end = '')
    print(string.format(
            Utility[-2], Utility[-1], Utility[0], Utility[1], Utility[2]
            )
    )
    print('P:\t', end = '')
    print('\t'.join(map(str, Policy.values())))
    # Copy of the Utility
    Ucopy = deepcopy(Utility)
    # Traversal all the states
    for s in State:
        # Store the maximun action utility: [Qvalue, action]
        Umax = [-float('inf'), None]
        # This is the: [argmax Q(s, a)] step
        for a in Action[s]:
            assert a in {-1, 1}, 'Action Error!'
            # prob = .6 if a == 1 else .65
            prob = .7 if a == 1 else .8
            R_s_a = prob * Reward[s-1] + (1 - prob) * Reward[s+1]
            U =  R_s_a + discount * (prob * Ucopy[s-1] + (1 - prob) * Ucopy[s+1])
            Umax = max(Umax, [U, a])
        # The maximun U value for targets are 0
        if Umax[1] == None: Umax[0] = 0
        # Stores the Optimal Action
        Utility[s] = Umax[0]
        Policy[s] = Umax[1]
    # Whether Converges
    if sum( [abs(Utility[s] - Ucopy[s]) for s in State] ) < 1e-10: break



